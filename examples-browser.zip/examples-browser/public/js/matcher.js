// matcher.js

async function fetchFaces() {
    const response = await fetch('/getFaces');
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json();
  }

// matcher.js

async function fetchFaces() {
    const response = await fetch('/getFaces');
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json();
  }
  
  async function createCustomFaceMatcher() {
    // Fetch the face images from the server
    const faceData = await fetchFaces();
  
    // Group images by name
    const faceGroups = faceData.refs.reduce((groups, face) => {
      if (!groups[face.name]) {
        groups[face.name] = [];
      }
      groups[face.name].push(face.img);
      return groups;
    }, {});
  
    const labeledFaceDescriptors = await Promise.all(
      Object.entries(faceGroups).map(async ([name, images]) => {
        const descriptors = [];
  
        for (const imgSrc of images) {
          const img = await faceapi.fetchImage(imgSrc);
          descriptors.push(await faceapi.computeFaceDescriptor(img));
        }
  
        return new faceapi.LabeledFaceDescriptors(name, descriptors);
      })
    );
  
    // Create and return the face matcher with the labeled descriptors
    return new faceapi.FaceMatcher(labeledFaceDescriptors);
  }  