let lastFaceImage = null;
let savedFaceImages = [];
let startedSaver = false;

async function updateRefereeResults() {
    if (!isFaceDetectionModelLoaded())
        return

    const videoEl = $('#inputVideo').get(0)
    const options = getFaceDetectorOptions()

    const detections = await faceapi.detectAllFaces(videoEl, options)
    const faceImages = await faceapi.extractFaces(videoEl, detections)

    const detectedIndex = detections.reduce((max, p, i, arr) => p.score > arr[max].score ? i : max, 0)

    /*
    const canvas = $('#overlay').get(0)
    const dims = faceapi.matchDimensions(canvas, videoEl, true)
    const resizedDetections = faceapi.resizeResults(detections, dims)
    faceapi.draw.drawDetections(canvas, resizedDetections)
    */

    if (detections.length > 0)
        lastFaceImage = faceImages[detectedIndex]

    if (lastFaceImage && !startedSaver) {
        startedSaver = true;
        scheduleSaveFace();
    }
}

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms)); 

async function scheduleSaveFace() {
  for (let i = 0; i < 3; i++) {
    await sleep(1000);
    saveFace();
  }
}

async function onPlayReferee(videoEl) {
  if (currentAbortController)
    currentAbortController.abort();

  const previousAbortController = currentAbortController;
  currentAbortController = new AbortController();
  const { signal } = currentAbortController;

  let onAbort = () => {};

  const delay = ms => new Promise((resolve, reject) => {
    const timeout = setTimeout(resolve, ms);
    onAbort = () => {
      clearTimeout(timeout);
      reject(new DOMException("Operation aborted", "AbortError"));
    };
    signal.addEventListener("abort", onAbort);
  });

  while (true) {
    try {
      await delay(33);

      console.log('video queued')

      if (!videoEl.currentTime || videoEl.paused || videoEl.ended || !isFaceDetectionModelLoaded())
        continue;

      updateRefereeResults();
    } catch (error) {
      if (error.name === "AbortError") {
        break;
      } else {
        console.error("An unexpected error occurred:", error);
      }
    }
  }

  // Clean up the abort event listener if this instance has been stopped
  if (previousAbortController)
    previousAbortController.signal.removeEventListener("abort", onAbort);
}

async function runRef() {
    changeInputSize(416)

    $('#detectorContainer').hide()
    $('signupContainer').hide();
    $('#refContainer').show()

    startVideo(onPlayReferee)
}

function saveFace() {
    if (!$('#refContainer').is(':visible'))
        return

    if (!lastFaceImage)
        return;

    console.log('pushing face image')
    savedFaceImages.push(lastFaceImage)
    //$('#facesContainer').append(lastFaceImage)

    if (savedFaceImages.length == 3) {
        savedFaceImages.forEach((faceImage, i) => {

            const dataURL = faceImage.toDataURL("image/png")
        
            $.ajax({
                type: "POST",
                url: "/saveFace",
                data: {
                    imgBase64: dataURL,
                    name: cachedName,
                    ref: i
                }
            }).done(function(o) {
                console.log('saved'); 
            });

            /*
            const link = document.createElement('a')
            link.download = `${$('#nameInput').val()}_ref_${i}.png`
            link.href = faceImage.toDataURL("image/png")
            link.click()
            */
        })

        // set faceText to say "done", wait 3 seconds then reload page
        $('#faceText').text('Done!')
        setTimeout(() => {
            location.reload()
        }, 3000)
    }
}