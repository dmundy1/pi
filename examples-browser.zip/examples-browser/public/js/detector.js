async function updateDetectorResults() {
  if (!isFaceDetectionModelLoaded())
    return

  if (faceMatcher === undefined)
    return

  const options = getFaceDetectorOptions()
  const results = await faceapi
    .detectAllFaces($('#inputVideo').get(0), options)
    .withFaceLandmarks()
    .withFaceDescriptors()

  const validResults = results
  .map(({ detection, descriptor }) => {
    const faceMatch = faceMatcher.findBestMatch(descriptor);
    return {
      detection,
      descriptor,
      label: faceMatch.label,
      labelString: faceMatch.toString(),
      distance: faceMatch.distance,
    };
  })
  .filter(result => result.label !== 'unknown')
  .sort((a, b) => a.distance - b.distance);

    const bestResult = validResults.length > 0 ? validResults[0] : { labelString: 'unknown' };
    $('#probably').text(`Probably: ${bestResult.labelString}`);

    if (bestResult.labelString != 'unknown' && bestResult.distance < 0.5) {
        cachedName = bestResult.labelString
        // set the signin container cached name (span)
        $('#cachedName').text(cachedName)
        $('#detectorContainer').hide()
        $('#confirmSigninContainer').show()

        $('#inputVideo').hide()

    }
}

async function onPlayDetector(videoEl) {
  if (currentAbortController)
    currentAbortController.abort();

  const previousAbortController = currentAbortController;
  currentAbortController = new AbortController();
  const { signal } = currentAbortController;

  const delay = ms => new Promise((resolve, reject) => {
    const timeout = setTimeout(resolve, ms);
    const onAbort = () => {
      clearTimeout(timeout);
      signal.removeEventListener("abort", onAbort);
      reject(new DOMException("Operation aborted", "AbortError"));
    };
    signal.addEventListener("abort", onAbort);
  });

  while (true) {
    try {
      await delay(33);

      if (!videoEl.currentTime || videoEl.paused || videoEl.ended || !isFaceDetectionModelLoaded()) {
        continue;
      }

      updateDetectorResults();
    } catch (error) {
      if (error.name === "AbortError") {
        break;
      } else {
        console.error("An unexpected error occurred:", error);
      }
    }
  }
}

async function runDetector() {
    $('#refContainer').hide()
    $('#signupContainer').hide()
    $('#detectorContainer').show()

    $('#signupButton').hide()
    // hide detector button
    $('#detectButton').hide()

    startVideo(onPlayDetector)
}