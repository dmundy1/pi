const express = require('express')
const path = require('path')
const { get } = require('request')
const fs = require("fs")
const bodyParser = require('body-parser')

const app = express()

app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(bodyParser({limit: '50mb'}));

const viewsDir = path.join(__dirname, 'views')
app.use(express.static(viewsDir))
app.use(express.static(path.join(__dirname, './public')))
app.use(express.static(path.join(__dirname, '../images')))
app.use(express.static(path.join(__dirname, '../media')))
app.use(express.static(path.join(__dirname, '../../weights')))
app.use(express.static(path.join(__dirname, '../../dist')))

app.get('/', (req, res) => res.redirect('/faceRec'))
/*
app.get('/face_detection', (req, res) => res.sendFile(path.join(viewsDir, 'faceDetection.html')))
app.get('/face_landmark_detection', (req, res) => res.sendFile(path.join(viewsDir, 'faceLandmarkDetection.html')))
app.get('/face_expression_recognition', (req, res) => res.sendFile(path.join(viewsDir, 'faceExpressionRecognition.html')))
app.get('/age_and_gender_recognition', (req, res) => res.sendFile(path.join(viewsDir, 'ageAndGenderRecognition.html')))
app.get('/face_extraction', (req, res) => res.sendFile(path.join(viewsDir, 'faceExtraction.html')))
app.get('/face_recognition', (req, res) => res.sendFile(path.join(viewsDir, 'faceRecognition.html')))
app.get('/video_face_tracking', (req, res) => res.sendFile(path.join(viewsDir, 'videoFaceTracking.html')))
app.get('/webcam_face_detection', (req, res) => res.sendFile(path.join(viewsDir, 'webcamFaceDetection.html')))
app.get('/webcam_face_landmark_detection', (req, res) => res.sendFile(path.join(viewsDir, 'webcamFaceLandmarkDetection.html')))
app.get('/webcam_face_expression_recognition', (req, res) => res.sendFile(path.join(viewsDir, 'webcamFaceExpressionRecognition.html')))
app.get('/webcam_age_and_gender_recognition', (req, res) => res.sendFile(path.join(viewsDir, 'webcamAgeAndGenderRecognition.html')))
app.get('/bbt_face_landmark_detection', (req, res) => res.sendFile(path.join(viewsDir, 'bbtFaceLandmarkDetection.html')))
app.get('/bbt_face_similarity', (req, res) => res.sendFile(path.join(viewsDir, 'bbtFaceSimilarity.html')))
app.get('/bbt_face_matching', (req, res) => res.sendFile(path.join(viewsDir, 'bbtFaceMatching.html')))
app.get('/bbt_face_recognition', (req, res) => res.sendFile(path.join(viewsDir, 'bbtFaceRecognition.html')))
app.get('/batch_face_landmarks', (req, res) => res.sendFile(path.join(viewsDir, 'batchFaceLandmarks.html')))
app.get('/batch_face_recognition', (req, res) => res.sendFile(path.join(viewsDir, 'batchFaceRecognition.html')))
*/

app.get('/faceRec', (req, res) => res.sendFile(path.join(viewsDir, 'videoFaceTracking.html')))
//app.get('/faceRef', (req, res) => res.sendFile(path.join(viewsDir, 'videoFaceTracking_save.html')))

app.post('/fetch_external_image', async (req, res) => {
  const { imageUrl } = req.body
  if (!imageUrl) {
    return res.status(400).send('imageUrl param required')
  }
  try {
    const externalResponse = await request(imageUrl)
    res.set('content-type', externalResponse.headers['content-type'])
    return res.status(202).send(Buffer.from(externalResponse.body))
  } catch (err) {
    return res.status(404).send(err.toString())
  }
})


app.post('/saveFace', (req, res) => {
  // extract data from request body
  const imgBase64 = req.body.imgBase64;
  const name = req.body.name;
  const ref = req.body.ref;

  // decode base64 image data
  const imgData = imgBase64.replace(/^data:image\/png;base64,/, "");
  const imgBuffer = Buffer.from(imgData, 'base64');

  // create file name and path
  const fileName = `${name}_ref_${ref}.png`;
  const folderPath = path.join(__dirname, `refs/${name}`);
  const filePath = path.join(folderPath, fileName);

  if (!fs.existsSync(folderPath))
    fs.mkdirSync(folderPath, { recursive: true });

  // write image data to file
  fs.writeFile(filePath, imgBuffer, (err) => {
    if (err) {
      console.error(err);
      res.status(500).json({ message: 'error saving file' });
    } else {
      console.log(`Saved file: ${filePath}`);
      res.status(200).json({ message: 'saved' });
    }
  });
});

app.get('/getFace', (req, res) => {
  // extract data from request body
  const name = req.query.name;

  // return base64 image data for all the refs
  const folderPath = path.join(__dirname, `refs/${name}`);
  const files = fs.readdirSync(folderPath);
  const refs = files.map(file => {
    const imgData = fs.readFileSync(path.join(folderPath, file), 'base64');
    return `data:image/png;base64,${imgData}`;
  });
  
  res.status(200).json({ refs });
});

app.get('/getFaces', (req, res) => {
  const folderPath = path.join(__dirname, 'refs');
  const subDirs = fs.readdirSync(folderPath).filter(subDir => fs.statSync(path.join(folderPath, subDir)).isDirectory());
  
  const refs = [];
  for (const subDir of subDirs) {
    const subDirPath = path.join(folderPath, subDir);
    const files = fs.readdirSync(subDirPath);
    for (const file of files) {
      if (file.endsWith('.png')) {
        const imgData = fs.readFileSync(path.join(subDirPath, file), 'base64');
        const [name, ref] = file.split('_ref_');
        refs.push({
          name,
          ref: ref.split('.')[0],
          img: `data:image/png;base64,${imgData}`
        });
      }
    }
  }

  res.status(200).json({ refs });
});

/*
      var fullName = $('#fullName').val();
      var pin = $('#pin').val();
      var data = {
        fullName: fullName,
        pin: pin
      }

      $.post('/signup', data, function(res) {
*/

app.post('/signup', (req, res) => {
  // extract data from request body
  const name = req.body.fullName;
  const pin = req.body.pin;

  // get the first word of the name and the first 4 digits of the pin
  const nameFirstWord = name.split(' ')[0];
  const pinFirst4Digits = pin.substring(0, 4);
  
  // create file name and path (/refs)
  const fileName = `${nameFirstWord}_${pinFirst4Digits}.db`;
  const folderPath = path.join(__dirname, 'refs');
  const filePath = path.join(folderPath, fileName);

  // save the file
  if (!fs.existsSync(folderPath))
    fs.mkdirSync(folderPath, { recursive: true });
  fs.writeFile(filePath, '', (err) => {
    if (err) {
      console.error(err);
      res.status(500).json({ message: 'error saving file' });
    } else {
      console.log(`Saved file: ${filePath}`);
      res.status(200).json({ message: 'saved' });
    }
  });
});

app.listen(3000, () => console.log('Listening on port 3000!'))

function request(url, returnBuffer = true, timeout = 10000) {
  return new Promise(function(resolve, reject) {
    const options = Object.assign(
      {},
      {
        url,
        isBuffer: true,
        timeout,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
        }
      },
      returnBuffer ? { encoding: null } : {}
    )

    get(options, function(err, res) {
      if (err) return reject(err)
      return resolve(res)
    })
  })
}